#!/bin/bash
TIMEFORMAT='%R'
time ./HelloWorld | grep [0-9]
