//Practical assignment 1
//Thread created by extending the Thread class

class TThread extends Thread {
	public void run() {
		System.out.println("Thread is running...");
	}
}