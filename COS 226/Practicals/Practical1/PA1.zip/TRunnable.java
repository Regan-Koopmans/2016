//Practical assignment 1
//Thread created by implementing the Runnable interface

class TRunnable implements Runnable {
	
	public void run() {
		System.out.println("Runnable thread is running...");
	}
}