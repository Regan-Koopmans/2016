#!/bin/bash
TIMEFORMAT='%R'
time ./HelloWorld.o | grep [0-9]

