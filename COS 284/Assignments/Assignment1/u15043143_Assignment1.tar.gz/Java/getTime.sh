#!/bin/bash
TIMEFORMAT='%R'
time java Main | grep [0-9]
